# openfst
This is a read-only unofficial mirror of [OpenFst](http://openfst.org/).

This is simply a mirror of recent OpenFst releases, for convenience. The OpenFst library was not developed here, the project is not active here, it does not accept pull requests here, and there is no issue tracker or wiki here. For all of these things, the [OpenFst project home](http://openfst.org/) is the best place to go.

[![Build Status](https://travis-ci.com/mjansche/openfst.svg?branch=master)](https://travis-ci.com/mjansche/openfst)
